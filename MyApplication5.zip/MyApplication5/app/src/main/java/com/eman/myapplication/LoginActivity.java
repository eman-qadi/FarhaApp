package com.eman.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class LoginActivity extends AppCompatActivity {
EditText phone;
EditText password ;
public User userData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        phone=findViewById(R.id.editTextPhone);
        password=findViewById(R.id.editTextTextPassword);
    }
    public void login(View view) {
        String phoneNumber =phone.getText().toString();
        String pass =password.getText().toString();
        // check if the infoLogin is T OR F
        String url = "http://192.168.1.3/login.php?phone="+phoneNumber+"&&password="+pass;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.INTERNET},
                    123);
        } else{
            LoginActivity.DownloadTextTask runner = new LoginActivity.DownloadTextTask();
            runner.execute(url);
        }

    }
    private String DownloadText(String URL)
    {
        int BUFFER_SIZE = 2000;
        InputStream in = null;
        try {
            in = OpenHttpConnection(URL);
        } catch (IOException e) {
            Log.d("Networking", e.getLocalizedMessage());
            return "";
        }

        InputStreamReader isr = new InputStreamReader(in);
        int charRead;
        String str = "";
        char[] inputBuffer = new char[BUFFER_SIZE];
        try {
            while ((charRead = isr.read(inputBuffer))>0) {
                //---convert the chars to a String---
                String readString = String.copyValueOf(inputBuffer, 0, charRead);
                str += readString;
                inputBuffer = new char[BUFFER_SIZE];
            }
            in.close();
        } catch (IOException e) {
            Log.d("Networking", e.getLocalizedMessage());
            return "";
        }
        return str;
    }
    private InputStream OpenHttpConnection(String urlString) throws IOException
    {
        InputStream in = null;
        int response = -1;

        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();

        if (!(conn instanceof HttpURLConnection))
            throw new IOException("Not an HTTP connection");
        try{
            HttpURLConnection httpConn = (HttpURLConnection) conn;
            httpConn.setAllowUserInteraction(false);
            httpConn.setInstanceFollowRedirects(true);
            httpConn.setRequestMethod("GET");
            httpConn.connect();
            response = httpConn.getResponseCode();
            if (response == HttpURLConnection.HTTP_OK) {
                in = httpConn.getInputStream();
            }
        }
        catch (Exception ex)
        {
            Log.d("Networking", ex.getLocalizedMessage());
            throw new IOException("Error connecting");
        }
        return in;
    }
    private class DownloadTextTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            return DownloadText(urls[0]);
        }
        @Override
        protected void onPostExecute(String result) {
            //Toast.makeText(getBaseContext(), result, Toast.LENGTH_LONG).show();
            String[] user = result.split(",");
            if(user.length <=0){
                String error ="Transmission failed ";
                Toast.makeText(getBaseContext(), error, Toast.LENGTH_LONG).show();
            }
            else if(user.length == 1){                  // faild login
                if(Integer.parseInt(user[0])==-1){
                    String error1 ="Password is incorrect\n" +
                            "Please try again ";
                    Toast.makeText(getBaseContext(), error1, Toast.LENGTH_LONG).show();
                }
                if(Integer.parseInt(user[0])==-2){
                    String error2 ="The phone number is invalid\n" +
                            "Please register first";
                    Toast.makeText(getBaseContext(), error2, Toast.LENGTH_LONG).show();
                }
                if(Integer.parseInt(user[0])==-3){
                    String error3 ="Data transmission error";
                    Toast.makeText(getBaseContext(), error3, Toast.LENGTH_LONG).show();
                }

            }else{          //login is successful
                userData =new User(Integer.parseInt(user[0]),user[1],user[2],user[3],
                        user[4],user[5],Integer.parseInt(user[6]),user[7],new Wallet(Integer.parseInt(user[9])));
                    Intent intent = new Intent(null, MainActivity.class);
                    startActivity(intent);
            }
        }
    }
}